﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aulas.Models;

namespace Aulas.Controller
{
    public class ArtigoController
    {
        private List<Artigo> _artigoList;
        public void InserirArtigo()
        {
            
        }

        public void RemoverArtigo()
        {

        }

        public void ListarArtigos()
        {
            
        }
    }
}
